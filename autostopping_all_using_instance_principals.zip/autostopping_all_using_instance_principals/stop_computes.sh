#!/bin/bash
# author: sinan.petrus.toma@oracle.com
# creation date: 5. Dec 2019
# 7th Jan. 2020: using instance principals

export OCI_CLI_AUTH=instance_principal
TENANCY_OCID=ocid1.tenancy.oc1..aaaaaaaa4cas4diymcy4marah3gnk6zijsmtkmzcbsepmgdnmk252afel66a

WHITELIST_FILE="/home/opc/ocicli/autostopping/whitelist_stop.txt"

OCI=$(which oci | cut -d ":" -f2)
ALL_REGIONS=$($OCI iam region list | grep -i name | cut -d ":" -f2 | cut -d "\"" -f2)

# 1. for each COMPARTMENT
ALL_COMPARTMENT_OCIDS=$($OCI iam compartment list --all --compartment-id-in-subtree true --compartment-id $TENANCY_OCID | grep -v "compartment-id" | grep "ocid1.compartment.oc1" | cut -d ":" -f2 | cut -d "\"" -f2)
for COMPARTMENT_OCID in $ALL_COMPARTMENT_OCIDS
do
	echo "COMPARTMENT_OCID = $COMPARTMENT_OCID"
	COMP_IN_WHITELIS=$(cat $WHITELIST_FILE | grep $COMPARTMENT_OCID | wc -l)
	NO_AUTO_STOPPING_COMP=$($OCI iam compartment get --compartment-id $COMPARTMENT_OCID | grep -i AutoStopping | grep -i NO | wc -l)
	if [ "${NO_AUTO_STOPPING_COMP}" -eq 1 ] || [ "${COMP_IN_WHITELIS}" -eq 1 ]; then
		echo "AutoStopping = NO or Compartment in whitelist file --> All Compute Instances on VM in this Compartment will NOT be stopped!"
	else
		# 2. for each REGION
		for REGION in $ALL_REGIONS
		do
			echo "REGION = $REGION"
			# 3. for each COMPUTE
			ALL_COMPUTE_OCIDS=$($OCI compute instance list --compartment-id $COMPARTMENT_OCID --region $REGION | grep "ocid1.instance.oc1" | cut -d ":" -f2 | cut -d "\"" -f2)
			for COMPUTE_OCID in $ALL_COMPUTE_OCIDS
			do
				echo "COMPUTE_OCID = $COMPUTE_OCID"
				# 4. check VM
				IS_VM=$($OCI compute instance get --instance-id $COMPUTE_OCID --region $REGION | grep -i shape | grep -i VM | wc -l)
				if [ "${IS_VM}" -eq 1 ]; then
					echo "Compute Instance shape is VM"
					# 5. check TAG
					NO_AUTO_STOPPING=$($OCI compute instance get --instance-id $COMPUTE_OCID --region $REGION | grep -i AutoStopping | grep -i NO | wc -l)
					if [ "${NO_AUTO_STOPPING}" -eq 1 ]; then
						echo "AutoStopping = NO --> COMPUTE will not be stopped! OCID=$COMPUTE_OCID"
					else
						$OCI compute instance action --instance-id $COMPUTE_OCID --action SOFTSTOP --region $REGION
						echo "COMPUTE is stopping..."
					fi # end NO_AUTO_STOPPING
				else
					echo "Compute Instance shape is NOT VM and will not be stopped!"
				fi # end IS_VM
			done # end COMPUTE		
		done # end REGION
	fi # end NO_AUTO_STOPPING_COMP
done #end COMPARTMENT

