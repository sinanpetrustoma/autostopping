#!/bin/bash
# author: sinan.petrus.toma@oracle.com
# creation date: May 29th 2020

export OCI_CLI_AUTH=instance_principal
TENANCY_OCID=ocid1.tenancy.oc1..aaaaaaaa5s27i4xnahmgkcmptb3utkexlzwfvmnicicl4kqv733jzej4sfuq

WHITELIST_FILE="/home/opc/ocicli/autostopping/whitelist.txt"

OCI=$(whereis oci | cut -d ":" -f2)
ALL_REGIONS=$($OCI iam region list | grep -i name | cut -d ":" -f2 | cut -d "\"" -f2)

# 1. for each COMPARTMENT
ALL_COMPARTMENT_OCIDS=$($OCI iam compartment list --all --compartment-id-in-subtree true --compartment-id $TENANCY_OCID | grep -v "compartment-id" | grep "ocid1.compartment.oc1" | cut -d ":" -f2 | cut -d "\"" -f2)
for COMPARTMENT_OCID in $ALL_COMPARTMENT_OCIDS
do
	echo "COMPARTMENT_OCID = $COMPARTMENT_OCID"
	COMP_IN_WHITELIS=$(cat $WHITELIST_FILE | grep $COMPARTMENT_OCID | wc -l)
	NO_AUTO_STOPPING_COMP=$($OCI iam compartment get --compartment-id $COMPARTMENT_OCID | grep -i AutoStopping | grep -i NO | wc -l)
	if [ "${NO_AUTO_STOPPING_COMP}" -eq 1 ] || [ "${COMP_IN_WHITELIS}" -eq 1 ]; then
		echo "AutoStopping = NO or Compartment in whitelist file --> All OAC instances in this Compartment will NOT be stopped!"
	else
		# 2. for each REGION
		for REGION in $ALL_REGIONS
		do
			echo "REGION = $REGION"
			# 3. for each OAC
			ALL_OAC_OCIDS=$($OCI analytics analytics-instance list --compartment-id $COMPARTMENT_OCID --region $REGION | grep "ocid1.analyticsinstance.oc1" | cut -d ":" -f2 | cut -d "\"" -f2)
			for OAC_OCID in $ALL_OAC_OCIDS
			do
				echo "OAC_OCID = $OAC_OCID"
				# 4. check TAG
				NO_AUTO_STOPPING=$($OCI analytics analytics-instance get --analytics-instance-id $OAC_OCID --region $REGION | grep -i AutoStopping | grep -i NO | wc -l)
				if [ "${NO_AUTO_STOPPING}" -eq 1 ]; then
					echo "AutoStopping = NO --> OAC will not be stopped!"
				else
					$OCI analytics analytics-instance stop --analytics-instance-id $OAC_OCID --region $REGION
					echo "OAC is stopping..."
				fi
			done # end OAC		
		done # end REGION
	fi # end NO_AUTO_STOPPING_COMP
done #end COMPARTMENT

