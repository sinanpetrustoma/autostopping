#!/bin/bash
# author: sinan.petrus.toma@oracle.com
# creation date: 5. Dec 2019
# 7th Jan. 2020: using instance principals

export OCI_CLI_AUTH=instance_principal
TENANCY_OCID=ocid1.tenancy.oc1..aaaaaaaa5s27i4xnahmgkcmptb3utkexlzwfvmnicicl4kqv733jzej4sfuq

WHITELIST_FILE="/home/opc/ocicli/autostopping/whitelist.txt"

OCI=$(whereis oci | cut -d ":" -f2)
ALL_REGIONS=$($OCI iam region list | grep -i name | cut -d ":" -f2 | cut -d "\"" -f2)

# 1. for each COMPARTMENT
ALL_COMPARTMENT_OCIDS=$($OCI iam compartment list --all --compartment-id-in-subtree true --compartment-id $TENANCY_OCID | grep -v "compartment-id" | grep "ocid1.compartment.oc1" | cut -d ":" -f2 | cut -d "\"" -f2)
for COMPARTMENT_OCID in $ALL_COMPARTMENT_OCIDS
do
	echo "COMPARTMENT_OCID = $COMPARTMENT_OCID"
	COMP_IN_WHITELIS=$(cat $WHITELIST_FILE | grep $COMPARTMENT_OCID | wc -l)
	NO_AUTO_STOPPING_COMP=$($OCI iam compartment get --compartment-id $COMPARTMENT_OCID | grep -i AutoStopping | grep -i NO | wc -l)
	if [ "${NO_AUTO_STOPPING_COMP}" -eq 1 ] || [ "${COMP_IN_WHITELIS}" -eq 1 ]; then
		echo "AutoStopping = NO or Compartment in whitelist file --> All DB System Nodes on VM in this Compartment will NOT be stopped!"
	else	
		# 2. for each REGION
		for REGION in $ALL_REGIONS
		do
			echo "REGION = $REGION"
			# 3. for each DBSYSTEM
			ALL_DBSYSTEM_OCIDS=$($OCI db system list --compartment-id $COMPARTMENT_OCID --region $REGION | grep "ocid1.dbsystem.oc1" | cut -d ":" -f2 | cut -d "\"" -f2)
			for DBSYSTEM_OCID in $ALL_DBSYSTEM_OCIDS
			do
				echo "DBSYSTEM_OCID = $DBSYSTEM_OCID"
				# 4. check VM
				IS_VM=$($OCI db system get --db-system-id $DBSYSTEM_OCID --region $REGION | grep -i shape | grep -i VM | wc -l)
				if [ "${IS_VM}" -eq 1 ]; then
					echo "DB SYSTEM shape is VM"
					# 5. check TAG
					NO_AUTO_STOPPING=$($OCI db system get --db-system-id $DBSYSTEM_OCID --region $REGION | grep -i AutoStopping | grep -i NO | wc -l)
					if [ "${NO_AUTO_STOPPING}" -eq 1 ]; then
						echo "AutoStopping = NO --> DBSYSTEM will not be stopped!"
					else
						# 6. for each NODE
						ALL_NODE_OCIDS=$($OCI db node list --compartment-id $COMPARTMENT_OCID --db-system-id $DBSYSTEM_OCID --region $REGION | grep ocid1.dbnode.oc1 | cut -d ":" -f2 | cut -d "\"" -f2)
						for NODE_OCID in $ALL_NODE_OCIDS
						do
							echo "NODE_OCID = $NODE_OCID"
							$OCI db node stop --db-node-id $NODE_OCID --region $REGION
							echo "DBSYSTEM NODE is stopping..."
						done # end NODE
					fi # end NO_AUTO_STOPPING
				else
					echo "DB SYSTEM shape is NOT VM and NODES will not be stopped!"
				fi # end IS_VM
			done # end DBSYSTEM		
		done # end REGION
	fi # end NO_AUTO_STOPPING_COMP
done #end COMPARTMENT
