#!/bin/bash
# author: sinan.petrus.toma@oracle.com
# creation date: 5. Dec 2019

ALL_COMPARTMENT_OCIDS=$(/home/opc/bin/oci iam compartment list --all --compartment-id-in-subtree true | grep -v "compartment-id" | grep "ocid1.compartment.oc1" | cut -d ":" -f2 | cut -d "\"" -f2)
for COMPARTMENT_OCID in $ALL_COMPARTMENT_OCIDS
do
   /home/opc/ocicli/autostopping/stop_dbsystem_nodes.sh $COMPARTMENT_OCID
done
