#!/bin/bash
# author: sinan.petrus.toma@oracle.com
# creation date: 5. Dec 2019

COMPARTMENT_OCID=$1
echo "COMPARTMENT_OCID = $COMPARTMENT_OCID"

# 1. for each REGION
ALL_REGIONS=$(/home/opc/bin/oci iam region list | grep -i name | cut -d ":" -f2 | cut -d "\"" -f2)
for REGION in $ALL_REGIONS
do
	echo "REGION = $REGION"
	# 2. for each COMPUTE
	ALL_COMPUTE_OCIDS=$(/home/opc/bin/oci compute instance list --compartment-id $COMPARTMENT_OCID --region $REGION | grep "ocid1.instance.oc1" | cut -d ":" -f2 | cut -d "\"" -f2)
	for COMPUTE_OCID in $ALL_COMPUTE_OCIDS
	do
		echo "COMPUTE_OCID = $COMPUTE_OCID"
		# 3. check TAG
		NO_AUTO_STOPPING=$(/home/opc/bin/oci compute instance get --instance-id $COMPUTE_OCID | grep -i AutoStopping | grep -i NO | wc -l)
		if [ "${NO_AUTO_STOPPING}" -eq 1 ]; then
			echo "AutoStopping = NO --> COMPUTE will not be stopped!"
		else
			/home/opc/bin/oci compute instance action --instance-id $COMPUTE_OCID --action SOFTSTOP --region $REGION
			echo "COMPUTE is stopping..."
		fi
	done # end COMPUTE		
done #end REGION

