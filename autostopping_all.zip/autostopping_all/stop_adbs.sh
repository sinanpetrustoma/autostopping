#!/bin/bash
# author: sinan.petrus.toma@oracle.com
# creation date: 5. Dec 2019

OCI=$(whereis oci | cut -d ":" -f2)

ALL_REGIONS=$($OCI iam region list | grep -i name | cut -d ":" -f2 | cut -d "\"" -f2)

# 1. for each COMPARTMENT
ALL_COMPARTMENT_OCIDS=$($OCI iam compartment list --all --compartment-id-in-subtree true | grep -v "compartment-id" | grep "ocid1.compartment.oc1" | cut -d ":" -f2 | cut -d "\"" -f2)
for COMPARTMENT_OCID in $ALL_COMPARTMENT_OCIDS
do
	echo "COMPARTMENT_OCID = $COMPARTMENT_OCID"
	NO_AUTO_STOPPING_COMP=$($OCI iam compartment get --compartment-id $COMPARTMENT_OCID | grep -i AutoStopping | grep -i NO | wc -l)
	if [ "${NO_AUTO_STOPPING_COMP}" -eq 1 ]; then
		echo "AutoStopping = NO --> All Autonomous Databases in this Compartment will NOT be stopped!"
	else
		# 2. for each REGION
		for REGION in $ALL_REGIONS
		do
			echo "REGION = $REGION"
			# 3. for each ADB
			ALL_ADB_OCIDS=$($OCI db autonomous-database list --compartment-id $COMPARTMENT_OCID --region $REGION | grep "ocid1.autonomousdatabase.oc1" | cut -d ":" -f2 | cut -d "\"" -f2)
			for ADB_OCID in $ALL_ADB_OCIDS
			do
				echo "ADB_OCID = $ADB_OCID"
				# 4. check TAG
				NO_AUTO_STOPPING=$($OCI db autonomous-database get --autonomous-database-id $ADB_OCID --region $REGION | grep -i AutoStopping | grep -i NO | wc -l)
				if [ "${NO_AUTO_STOPPING}" -eq 1 ]; then
					echo "AutoStopping = NO --> ADB will not be stopped!"
				else
					$OCI db autonomous-database stop --autonomous-database-id $ADB_OCID --region $REGION
					echo "ADB is stopping..."
				fi
			done # end ADB		
		done # end REGION
	fi # end NO_AUTO_STOPPING_COMP
done #end COMPARTMENT
