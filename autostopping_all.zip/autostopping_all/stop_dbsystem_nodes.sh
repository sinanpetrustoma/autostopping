#!/bin/bash
# author: sinan.petrus.toma@oracle.com
# creation date: 5. Dec 2019

ALL_REGIONS=$(/home/opc/bin/oci iam region list | grep -i name | cut -d ":" -f2 | cut -d "\"" -f2)

# 1. for each COMPARTMENT
ALL_COMPARTMENT_OCIDS=$(/home/opc/bin/oci iam compartment list --all --compartment-id-in-subtree true | grep -v "compartment-id" | grep "ocid1.compartment.oc1" | cut -d ":" -f2 | cut -d "\"" -f2)
for COMPARTMENT_OCID in $ALL_COMPARTMENT_OCIDS
do
	echo "COMPARTMENT_OCID = $COMPARTMENT_OCID"
	# 2. for each REGION
	for REGION in $ALL_REGIONS
	do
		echo "REGION = $REGION"
		# 3. for each DBSYSTEM
		ALL_DBSYSTEM_OCIDS=$(/home/opc/bin/oci db system list --compartment-id $COMPARTMENT_OCID --region $REGION | grep "ocid1.dbsystem.oc1" | cut -d ":" -f2 | cut -d "\"" -f2)
		for DBSYSTEM_OCID in $ALL_DBSYSTEM_OCIDS
		do
			echo "DBSYSTEM_OCID = $DBSYSTEM_OCID"
			# 4. check TAG
			NO_AUTO_STOPPING=$(/home/opc/bin/oci db system get --db-system-id $DBSYSTEM_OCID | grep -i AutoStopping | grep -i NO | wc -l)
			if [ "${NO_AUTO_STOPPING}" -eq 1 ]; then
				echo "AutoStopping = NO --> DBSYSTEM will not be stopped!"
			else
				# 5. for each NODE
				ALL_NODE_OCIDS=$(/home/opc/bin/oci db node list --compartment-id $COMPARTMENT_OCID --db-system-id $DBSYSTEM_OCID | grep ocid1.dbnode.oc1 | cut -d ":" -f2 | cut -d "\"" -f2)
				for NODE_OCID in $ALL_NODE_OCIDS
				do
					echo "NODE_OCID = $NODE_OCID"
					/home/opc/bin/oci db node stop --db-node-id $NODE_OCID --region $REGION
					echo "DBSYSTEM NODE is stopping..."
				done # end NODE
			fi
		done # end DBSYSTEM		
	done #end REGION
done #end COMPARTMENT
