
Step 1:
Install and configure OCI CLI on a Compute Intance (Linux VM with one CPU would be ok) in your tenancy.
https://docs.cloud.oracle.com/iaas/Content/API/SDKDocs/cliinstall.htm
It takes about 10min


Step 2:
Save the delivered shell scripts on the VM, e.g. in /home/opc/ocicli/autostopping/
Create a sub-directory named log: i.e. /home/opc/ocicli/autostopping/log/


Step 3:
Change the WHITELIST_FILE path in the .sh scripts accordingly. See Step 7.
e.g.: WHITELIST_FILE="/home/opc/ocicli/autostopping/whitelist.txt"


Step 4:
Make the shell scripts executable
chmod +x /home/opc/ocicli/autostopping/*.sh


Step 5: 
Create an automation using corntab. In the following example shutting down the resources every day at 6p.m. and keeping the log files for 7 days.
0 18 * * * /home/opc/ocicli/autostopping/stop_adbs_all_compartments.sh > /home/opc/ocicli/autostopping/log/stop_adbs_`date '+\%Y\%m\%d_\%H\%M\%S'`.log
0 18 * * * /home/opc/ocicli/autostopping/stop_dbsystem_nodes_all_compartments.sh > /home/opc/ocicli/autostopping/log/stop_dbsystem_nodes_`date '+\%Y\%m\%d_\%H\%M\%S'`.log
0 18 * * * /home/opc/ocicli/autostopping/stop_computes_all_compartments.sh > /home/opc/ocicli/autostopping/log/stop_computes_`date '+\%Y\%m\%d_\%H\%M\%S'`.log
3 * * * * find /home/opc/ocicli/autostopping/log/ -type f -mtime +7 -name '*.log' -execdir rm -- '{}' \;


IMPORTANT: the scripts do not start the resources in the next morning:
Option 1: every one in the team starts only the resources needed manually.
Option 2: duplicate the scripts and replace "stop" by "start" and create crontab roles to run them


Step 6 (Optional):
To prevent specific instances from auto stop, add a TAG named "AutoStopping" with the value "NO" to the resource


Step 7 (Optional):
To prevent all ADBs, Compute, and DB Systems of a specific Compartment to be stopped, add the TAG to the Compartment itself.
Some Compartments like ManagedCompartmentForPaaS cannot be edited. In this case add the Compartment OCID ot the whitelist.txt file.
